/*
#include "lidar_localization/path_tracking/purePursuit.hpp"

namespace lidar_localization
{
	
	purePursuit::purePursuit(const vector<purePursuit::Position> &wayPoints, float wheelBase, float setIndex) 
	{
		m_wheelBase=wheelBase; 
		m_setIndex=setIndex;
        m_lowerIndex=0;
		m_flagForFirst=true;
		m_upperIndex = wayPoints.size();
		if (m_lowerIndex >= m_upperIndex)
		{
			cout << "Warning: no data!!!!" << endl;
		}

		for (int i = 0; i < m_upperIndex; i++)
		{

			m_wayPoints.push_back(wayPoints[i]);
		}

		m_foundIndex = 0;
		m_brake = 0.0;
		m_speed = 0.0;
		m_nearestIndex = 0;
	}

	void purePursuit::FindIndex(const purePursuit::Position &vehiclePos)
	{

		float minValue = 999999999999999999.0;
		float dx;
		float dy;
		float dist;

		if (m_flagForFirst)
		{

			for (int i = 0; i < m_upperIndex; i++)
			{
				dx = vehiclePos.x - m_wayPoints[i].x;
				dy = vehiclePos.y - m_wayPoints[i].y;
				dist = sqrt(dx * dx + dy * dy);
				if (dist < minValue)
				{

					minValue = dist;
					m_nearestIndex = i;
				}
			}

			m_flagForFirst = false;
		}
		else
		{
			int searchRange = 20;
			int upper, lower;
			lower = max(0, m_nearestIndex - searchRange);
			upper = min(m_upperIndex - 1, m_nearestIndex + searchRange);
			for (int i = lower; i < upper; i++)
			{
				dx = vehiclePos.x - m_wayPoints[i].x;
				dy = vehiclePos.y - m_wayPoints[i].y;
				dist = sqrt(dx * dx + dy * dy);
				if (dist < minValue)
				{

					minValue = dist;
					m_nearestIndex = i;
				}
			}
		}

		m_foundIndex = m_nearestIndex + m_setIndex;
	}

	void purePursuit::Tranfer(const purePursuit::Position &vehiclePos)
	{

		m_globalPos = m_wayPoints[m_foundIndex];

		float theta = vehiclePos.heading * 3.1415926 / 180.0;
		float tmp_x, tmp_y;
		tmp_x = m_globalPos.x - vehiclePos.x;
		tmp_y = m_globalPos.y - vehiclePos.y;
		m_vehiclePos.x = cos(theta) * tmp_x - sin(theta) * tmp_y;
		m_vehiclePos.y = sin(theta) * tmp_x + cos(theta) * tmp_y
	}

	purePursuit::ctrlCommand purePursuit::VehicleControl(const purePursuit::Position &vehiclePos, const int aeb=0)
	{
		ctrlCommand cmd;
		if (aeb == 1)
		{
			cmd.speed = 0.0f;
		}
		else if (aeb == 0)
		{
			cmd.speed = 3.3f;
			//PIDforSpeed();
		}
		FindIndex(vehiclePos);
		Tranfer(vehiclePos);
		float steerCmd;
		float ld;
		float yValue;
		ld = sqrt(m_vehiclePos.x * m_vehiclePos.x + m_vehiclePos.y * m_vehiclePos.y);
		yValue = m_vehiclePos.y;
		steerCmd = atan(2 * m_wheelBase * yValue / (ld * ld)) * 180.0 / 3.1415926; // if it is wrong, please add "-" before atan();
		return cmd;
	}

} // namespace lidar_localization*/
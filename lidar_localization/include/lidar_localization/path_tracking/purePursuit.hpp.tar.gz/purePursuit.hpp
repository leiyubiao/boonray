#ifndef PURE_PURSUIT_HPP_
#define PURE_PURSUIT_HPP_
#include <iostream>
#include <vector>
#include <cmath>
#include <memory>
using namespace std;

namespace lidar_localization
{
	class purePursuit
	{

	public:
		struct Position
		{

			float x;
			float y;
			float heading;
			Position(float _x = 0.0f, float _y = 0.0f, float _heading = 0.0f) : x(_x), y(_y), heading(_heading) {}
			Position &operator=(const Position &_tmp)
			{
				x = _tmp.x;
				y = _tmp.y;
				heading = _tmp.heading;
				return *this;
			}
		};

		struct ctrlCommand
		{

			float steer; // deg
			float speed;
			ctrlCommand &operator=(const ctrlCommand &ctrl)
			{
				steer = ctrl.steer;
				speed = ctrl.speed;
				return *this;
			}
		};
	public:
	Position m_globalPos;
	private:
		vector<Position> m_wayPoints; //set the wappoints as global parameter
		bool m_flagForFirst;
		int m_lowerIndex;
		int m_upperIndex;
		int m_setIndex;
		int m_foundIndex;
		int m_nearestIndex;

		float m_wheelBase;

		float m_speed;
		float m_brake;

		
		Position m_vehiclePos;

	private:
		void FindIndex(const Position &vehiclePos);
		void Tranfer(const Position &vehiclePos);
		void PIDforSpeed(void); // reserved;

	public:
		purePursuit(const vector<Position> &wayPoints, float wheelBase, float setIndex);
		/*{

			m_upperIndex = wayPoints.size();
			if (m_lowerIndex >= m_upperIndex)
			{
				cout << "Warning: no data!!!!" << endl;
			}

			for (int i = 0; i < m_upperIndex; i++)
			{

				m_wayPoints.push_back(wayPoints[i]);
			}

			m_foundIndex = 0;
			m_brake = 0.0;
			m_speed = 0.0;
			m_nearestIndex = 0;
		}*/
		ctrlCommand VehicleControl(const Position &vehiclePos, const int aeb = 0);
		~purePursuit(){};
	};

	purePursuit::purePursuit(const vector<purePursuit::Position> &wayPoints, float wheelBase, float setIndex)
	{
		m_wheelBase = wheelBase;
		m_setIndex = setIndex;
		m_lowerIndex = 0;
		m_flagForFirst = true;
		m_upperIndex = wayPoints.size();
		if (m_lowerIndex >= m_upperIndex)
		{
			cout << "Warning: no data!!!!" << endl;
		}

		for (int i = 0; i < m_upperIndex; i++)
		{

			m_wayPoints.push_back(wayPoints[i]);
		}

		m_foundIndex = 0;
		m_brake = 0.0;
		m_speed = 0.0;
		m_nearestIndex = 0;
	}

	void purePursuit::FindIndex(const purePursuit::Position &vehiclePos)
	{

		float minValue = 999999999999999999.0;
		float dx;
		float dy;
		float dist;

		if (m_flagForFirst)
		{

			for (int i = 0; i < m_upperIndex; i++)
			{
				dx = vehiclePos.x - m_wayPoints[i].x;
				dy = vehiclePos.y - m_wayPoints[i].y;
				dist = sqrt(dx * dx + dy * dy);
				if (dist < minValue)
				{

					minValue = dist;
					m_nearestIndex = i;
				}
			}

			m_flagForFirst = false;
		}
		else
		{
			int searchRange = 20;
			int upper, lower;
			lower = max(0, m_nearestIndex - searchRange);
			upper = min(m_upperIndex - 1, m_nearestIndex + searchRange);
			for (int i = lower; i < upper; i++)
			{
				dx = vehiclePos.x - m_wayPoints[i].x;
				dy = vehiclePos.y - m_wayPoints[i].y;
				dist = sqrt(dx * dx + dy * dy);
				if (dist < minValue)
				{

					minValue = dist;
					m_nearestIndex = i;
				}
			}
		}

		m_foundIndex = m_nearestIndex + m_setIndex;
		m_foundIndex = min(m_foundIndex,m_upperIndex-1);
	}

	void purePursuit::Tranfer(const purePursuit::Position &vehiclePos)
	{

		m_globalPos = m_wayPoints[m_foundIndex];

		float theta = vehiclePos.heading * 3.1415926 / 180.0;
		float tmp_x, tmp_y;
		tmp_x = m_globalPos.x - vehiclePos.x;
		tmp_y = m_globalPos.y - vehiclePos.y;
		m_vehiclePos.x = cos(theta) * tmp_x - sin(theta) * tmp_y;
		m_vehiclePos.y = sin(theta) * tmp_x + cos(theta) * tmp_y;
	}

	purePursuit::ctrlCommand purePursuit::VehicleControl(const purePursuit::Position &vehiclePos, const int aeb )
	{
		ctrlCommand cmd;
		if (aeb == 1 ||abs(m_upperIndex - m_nearestIndex) < 25)
		{
			cmd.speed = 0.0f;
			cmd.steer = 0.0f;
		}
		else if (aeb == 0)
		{
			cmd.speed = 8.0f;
			//PIDforSpeed();
		}
		FindIndex(vehiclePos);
		Tranfer(vehiclePos);
		float steerCmd;
		float ld;
		float yValue;
		ld = sqrt(m_vehiclePos.x * m_vehiclePos.x + m_vehiclePos.y * m_vehiclePos.y);
		/**
		 * @var		mixed	-m_vehiclePos.y
		 */
		yValue = -m_vehiclePos.y;
		steerCmd = atan(2 * m_wheelBase * yValue / (ld * ld)) * 180.0 / 3.1415926; // if it is wrong, please add "-" before atan();
		steerCmd = min(25.0f, max(-25.0f,steerCmd));
		cmd.steer = steerCmd;
		cout<<"the calcuted x = "<< m_vehiclePos.x <<" , "<<m_vehiclePos.y<<endl;
		cout<<"steer="<<steerCmd<<endl;
		cout<<"speed="<<cmd.speed<<endl;
		return cmd;
	}
} // namespace lidar_localization
#endif

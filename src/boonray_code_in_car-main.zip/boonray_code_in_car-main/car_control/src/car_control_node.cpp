#include <iostream>
#include <ros/ros.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>
#include <sensor_msgs/PointCloud2.h>
//#include "ICANCmd.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
//#include "ECanVci.h"//广成的
#include "controlcan.h"//自带的
#include <geometry_msgs/PoseStamped.h>
#define msleep(ms)  usleep((ms)*1000)
#define min(a,b)  (((a) < (b)) ? (a) : (b))


#define MAX_CHANNELS  2
#define CHECK_POINT  200
#define RX_WAIT_TIME  0
#define RX_BUFF_SIZE  1


#define height 0

using namespace std;

unsigned int gDevType = 0;
unsigned int gDevIdx = 0;
unsigned int gChMask = 0;
unsigned int gBaud = 0;
unsigned char gTxType = 0;
unsigned int gTxSleep = 0;
unsigned int gTxFrames = 0;
unsigned int CAN_ID=0;


//转角±30度，左负右正。对应-1024~1024 ,D_R=1表示前进，-1表示后退
VCI_CAN_OBJ generateCommand(int D_R,float speed,float steering_angle)
{
       VCI_CAN_OBJ can_message;
	can_message.ID=0x183;
	can_message.SendType=0;
	can_message.RemoteFlag=0;
	can_message.ExternFlag=0;
	can_message.DataLen=8;
	
	unsigned int speed_num=abs(speed*10);
	unsigned int steering_angle_num=abs(steering_angle)*1024/30;
	can_message.Data[0]=speed_num&0x00FF;
	can_message.Data[1]=(speed_num>>8)&0x00FF;
	can_message.Data[2]=0x00;
	can_message.Data[3]=0x00;	
	unsigned int steer=(steering_angle>=0)?steering_angle_num:(((~steering_angle_num)+1));
	//printf("data  %x \n",steering_angle_num);
	//printf("~  %x \n",(~steering_angle_num)&0xFFFF);
	//printf("~+1  %x \n",((~steering_angle_num)+1)&0xFFFF);
	
	can_message.Data[4]=steer&0x00FF;
	can_message.Data[5]=(steer>>8)&0x00FF;
	

	
	can_message.Data[6]=(D_R>0)?0x01:0x03;
	can_message.Data[7]=0x80;
	
	return can_message;
	
}

void printCan(VCI_CAN_OBJ can)
{
    if(can.ID==804||can.ID==805||can.ID==807||can.ID==810)//我们需要的数据,can消息的ID是unsigned int
    {
        printf("ID = %d \n",can.ID);
        printf("Data:  ");
        for(int i=0;i<8;++i)
        {
            printf("%x ",can.Data[i]);
        }
        printf("\n");
    }
}

void Receive_data()
{
    VCI_CAN_OBJ can;
    int len=VCI_Receive(gDevType, gDevIdx, CAN_ID, &can, 1, 1000/*ms*/);
    printf("receive len= %d\n",len);
    printCan(can);
}

void Receive_datas()
{
    VCI_CAN_OBJ can[10];
    int len=VCI_Receive(gDevType, gDevIdx, CAN_ID, can, 10, 1000/*ms*/);
    printf("receive len= %d\n",len);
    for(int i=0;i<10;++i)
        printCan(can[i]);
}



unsigned int s2n(const char *s)
{
    unsigned l = strlen(s);
    unsigned v = 0;
    unsigned h = (l > 2 && s[0] == '0' && (s[1] == 'x' || s[1] == 'X'));
    unsigned char c;
    unsigned char t;
    if (!h) return atoi(s);
    if (l > 10) return 0;
    for (s += 2; c = *s; s++)
    {
        if (c >= 'A' && c <= 'F') c += 32;
        if (c >= '0' && c <= '9') t = c - '0';
        else if (c >= 'a' && c <= 'f') t = c - 'a' + 10;
        else return 0;
        v = (v << 4) | t;
    }
    return v;
}

bool init()
{
    gDevType = s2n("4");        //argv[1]   //设备类型号 3-USBCAN I, 4-USBCAN II 
    gDevIdx = s2n("0");         //argv[2]   //设备索引号 0-只有一个设备，0 or 1-有两个设备
    gChMask = s2n("0");         //argv[3]   //CAN通道号 0-CAN0, 1-CAN1
    gBaud = s2n("0x1c00");      //argv[4]   //通讯波特率：0x1C00=500kbps
    gTxType = s2n("0");         //argv[5]   //发送类型 normal
    gTxSleep = s2n("1");        //argv[6]   //延时时间ms
    gTxFrames = s2n("1000");    //argv[7]
    printf("DevType=%d, DevIdx=%d, ChMask=0x%x, Baud=0x%04x, TxType=%d, TxSleep=%d, TxFrames=0x%08x(%d)\n",
        gDevType, gDevIdx, gChMask, gBaud, gTxType, gTxSleep, gTxFrames, gTxFrames);

    if (!VCI_OpenDevice(gDevType, gDevIdx, 0)) 
    {     //开启设备
        printf("VCI_OpenDevice failed\n");
        return false;
    }
    printf("VCI_OpenDevice succeeded\n");


    // ----- init & start -------------------------------------------------

    VCI_INIT_CONFIG config;
    config.AccCode = 0;
    config.AccMask = 0xffffffff;
    config.Filter = 1;
    config.Mode = 0;
    config.Timing0 = 0x00;
    config.Timing1 = 0x1c;
    

    if (!VCI_InitCAN(gDevType, gDevIdx, CAN_ID, &config))
    {
        printf("VCI_InitCAN(%d) failed\n", CAN_ID);
        return false;
    }
    printf("VCI_InitCAN(%d) succeeded\n", CAN_ID);

    if (!VCI_StartCAN(gDevType, gDevIdx, CAN_ID))
    {
        printf("VCI_StartCAN(%d) failed\n", CAN_ID);
        return false;
    }
    printf("VCI_StartCAN(%d) succeeded\n", CAN_ID);
    
    return true;

}    
//转角±30度，左负右正。对应-1024~1024 ,D_R=1表示前进，-1表示后退
int sendCommand(int D_R,float speed,float steering_angle)

{
      VCI_CAN_OBJ can;
   
      can=generateCommand(D_R,speed,steering_angle);
       printCan(can);

      int length=VCI_Transmit(gDevType, gDevIdx, 0, &can, 1);//0是canID，可能为0 1;
      int flag=1;
      if (1 != length)
      {
            printf("CAN%d TX failed: ID=%08x\n", 0, can.ID);
            flag = 0;
      }
      msleep(20);  
    return flag;
}

//pose的x存储的速度值，y存储的转角值
void car_command_msg_callback(const geometry_msgs::PoseStampedConstPtr& command_ptr)
{
    printf("get car control command speed=%f, steer=%f",command_ptr->pose.position.x,command_ptr->pose.position.y);
    sendCommand(1,command_ptr->pose.position.x,command_ptr->pose.position.y);
}


int main(int argc, char **argv)
{
	ros::init(argc, argv, "car_control_node");
	ros::NodeHandle nh;

    ros::Subscriber sub_command=nh.subscribe<geometry_msgs::PoseStamped>("/car_command", 1000, car_command_msg_callback);
	
	if(!init())
		return 0;
    /*
    int k=100;
    while(--k){
    		    //int value=sendCommand(1,15,20);
        Receive_datas();
    }*/

    ros::spin();

    VCI_CloseDevice(gDevType, gDevIdx);         //关闭设备
    printf("VCI_CloseDevice\n");
    return 0;
}
